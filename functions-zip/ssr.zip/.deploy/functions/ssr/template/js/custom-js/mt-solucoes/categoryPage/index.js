import { insertTitlePage } from "./insertTitlePage"

export const initCategoryPage = () => {
  insertTitlePage();
}