import { initSubMenu } from "."

export const setSubMenuMobile = () => {
  initSubMenu();
}